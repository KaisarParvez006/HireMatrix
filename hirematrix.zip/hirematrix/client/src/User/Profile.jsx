import { useState, useEffect } from 'react';
import { useAuth } from '../state';
import { useToast } from '../Components/Toast';
import api from '../api';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fullUser, setFullUser] = useState(null);

  const [form, setForm] = useState({
    name: '',
    phone: '',
    skills: '',
    experience: '',
    companyName: '',
    companyWebsite: '',
    designation: '',
    resume: null
  });

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data } = await api.get('/auth/me');
      setFullUser(data);
      setForm({
        name: data.name || '',
        phone: data.phone || '',
        skills: (data.skills || []).join(', '),
        experience: data.experience || '',
        companyName: data.companyDetails?.companyName || '',
        companyWebsite: data.companyDetails?.companyWebsite || '',
        designation: data.companyDetails?.designation || '',
        resume: null
      });
    } catch (err) {
      toast.error('Failed to fetch profile details');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => {
        if (v !== null && v !== undefined) fd.append(k, v);
      });

      const { data } = await api.put('/auth/me', fd, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success('Profile updated successfully');
      updateUser(data.user);
      if (data.user.resume) {
        setFullUser(prev => ({ ...prev, resume: data.user.resume }));
      }
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="loading-screen"><span className="spinner" /> Loading profile...</div>;

  return (
    <div className="animate-in">
      <div className="page-header">
        <h2>My Profile</h2>
        <p>View and update your account information</p>
      </div>

      <div className="card" style={{ maxWidth: 800 }}>
        <form onSubmit={handleSave} className="stack">
          <div className="form-grid form-grid-2">
            <div className="form-group">
              <label>Full Name</label>
              <input 
                value={form.name} 
                onChange={e => setForm({...form, name: e.target.value})} 
                required 
              />
            </div>
            <div className="form-group">
              <label>Email Address</label>
              <input value={fullUser?.email} disabled style={{ opacity: 0.6, cursor: 'not-allowed' }} />
              <span style={{ fontSize: '0.7rem', color: 'var(--ink3)' }}>Email cannot be changed</span>
            </div>
          </div>

          <div className="form-grid form-grid-2">
            <div className="form-group">
              <label>Phone Number</label>
              <input 
                value={form.phone} 
                onChange={e => setForm({...form, phone: e.target.value})} 
                placeholder="+91 9876543210"
              />
            </div>
            <div className="form-group">
              <label>Role</label>
              <input value={fullUser?.role} disabled style={{ opacity: 0.6, cursor: 'not-allowed' }} />
            </div>
          </div>

          {fullUser?.role === 'Applicant' && (
            <>
              <div className="divider" />
              <div className="form-group">
                <label>Resume</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <input 
                    type="file" 
                    accept=".pdf,.doc,.docx" 
                    onChange={e => setForm({...form, resume: e.target.files?.[0] || null})} 
                    style={{ flex: 1 }}
                  />
                  {fullUser?.resume && (
                    <a 
                      href={`/${fullUser.resume}`} 
                      target="_blank" 
                      rel="noreferrer"
                      className="btn btn-sm btn-ghost"
                    >
                      View Current
                    </a>
                  )}
                </div>
                <span style={{ fontSize: '0.75rem', color: 'var(--ink3)' }}>PDF, DOC or DOCX — max 5MB</span>
              </div>
              <div className="form-group">
                <label>Skills (comma separated)</label>
                <input 
                  value={form.skills} 
                  onChange={e => setForm({...form, skills: e.target.value})} 
                  placeholder="React, Node.js, MongoDB..."
                />
              </div>
              <div className="form-group">
                <label>Professional Experience</label>
                <textarea 
                  value={form.experience} 
                  onChange={e => setForm({...form, experience: e.target.value})} 
                  placeholder="Tell us about your work history..."
                />
              </div>
            </>
          )}

          {['Recruiter', 'HR'].includes(fullUser?.role) && (
            <>
              <div className="divider" />
              <h4 style={{ marginBottom: 8, color: 'var(--ink)' }}>Company Details</h4>
              <div className="form-group">
                <label>Company Name</label>
                <input 
                  value={form.companyName} 
                  onChange={e => setForm({...form, companyName: e.target.value})} 
                  required
                />
              </div>
              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label>Company Website</label>
                  <input 
                    value={form.companyWebsite} 
                    onChange={e => setForm({...form, companyWebsite: e.target.value})} 
                    placeholder="https://company.com"
                  />
                </div>
                <div className="form-group">
                  <label>Your Designation</label>
                  <input 
                    value={form.designation} 
                    onChange={e => setForm({...form, designation: e.target.value})} 
                    placeholder="Senior Recruiter"
                  />
                </div>
              </div>
            </>
          )}

          <div style={{ marginTop: 12, display: 'flex', justifyContent: 'flex-end' }}>
            <button className="btn btn-lg" type="submit" disabled={saving}>
              {saving ? <><span className="spinner" /> Saving...</> : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
